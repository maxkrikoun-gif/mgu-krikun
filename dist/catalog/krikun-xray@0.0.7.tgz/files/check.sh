#!/bin/sh
# SPDX-License-Identifier: MIT
# mgu-deploy check: без file(1) — на Yocto MGU его часто нет (idrive7-apps pattern).
set -eu
D="${MGU_TOOL_CURRENT:-/var/opt/krikun-xray/current}"
CFG="${MGU_TOOL_CONF:-/var/opt/krikun-xray/conf/config.json}"
[ -x "$D/xray" ] || { echo "krikun-xray: нет $D/xray"; exit 1; }
[ -x "$D/krikun-runas" ] || { echo "krikun-xray: нет $D/krikun-runas"; exit 1; }
if ! "$D/xray" version >/dev/null 2>&1; then
	echo "krikun-xray: xray не запускается (ожидается linux-amd64 ELF)"
	exit 1
fi
rc=0
"$D/krikun-runas" 2>/dev/null || rc=$?
if [ "$rc" -ne 2 ]; then
	echo "krikun-xray: krikun-runas не ELF или повреждён (rc=$rc)"
	exit 1
fi
if [ ! -f "$CFG" ]; then
	echo "krikun-xray: конфиг пока нет ($CFG) — idle до USB KRIKUN/xray.json или «Krikun: сеть»"
	exit 0
fi
if ! grep -q '127.0.0.1' "$CFG"; then
	echo "krikun-xray: в конфиге должен быть inbound на 127.0.0.1"
	exit 1
fi
echo "krikun-xray: конфиг найден"
exit 0